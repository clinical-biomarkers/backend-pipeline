import os
import string
import random
import hashlib
import json
import datetime,time
import pytz
from collections import OrderedDict
from bson import json_util, ObjectId


from glygen.db import get_mongodb
from glygen.util import get_errors_in_query, sort_objects, order_obj, clean_obj, get_paginated_sections, cache_hitlist, transform_query_term, get_hash_id
from glygen.indexlib import use_indexed_search


def biomarker_search_init(config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("biomarker_searchinit",{}, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    collection = "c_searchinit"
    res_obj =  dbh[collection].find_one({})

    return res_obj["biomarker"]




def search_simple(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj


    #Collect errors 
    error_list = get_errors_in_query("biomarker_search_simple", query_obj,config_obj)
    if error_list != []:
        return {"error_list":error_list}


    new_query_obj = json.loads(json.dumps(query_obj))
    if new_query_obj["term_category"] == "any":
        new_query_obj["term"] = transform_query_term(new_query_obj["term"])


    record_type = "biomarker"
    api_name = "biomarker_search_simple"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    #cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    #if cached_obj != None:
    #    if len(cached_obj["results"]) > 0:
    #        return {"list_id":list_id}

    mongo_query = get_simple_mongo_query(new_query_obj)
    #return mongo_query

    collection = "c_biomarker"
    record_list = []
    prj_obj = {"biomarker_id":1}
    for obj in dbh[collection].find(mongo_query,prj_obj):
        record_list.append(obj["biomarker_id"])
    #return record_list

    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":"biomarker_search_simple"
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}
    res_obj["query"] = query_obj
    res_obj["resultcount"] = len(record_list)

    return res_obj





def biomarker_detail(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj


    #Collect errors 
    error_list = get_errors_in_query("biomarker_detail", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}
    collection = "c_biomarker"




    mongo_query = {"biomarker_id":{"$eq":query_obj["biomarker_id"]}}
    obj = dbh[collection].find_one(mongo_query)
    #check for post-access error, error_list should be empty upto this line
    post_error_list = []
    if obj == None:
        post_error_list.append({"error_code":"non-existent-record"})
        return {"error_list":post_error_list}

    
    if "paginated_tables" in query_obj:
        table_id_list = []
        for o in query_obj["paginated_tables"]:
            if o["table_id"] not in table_id_list:
                table_id_list.append(o["table_id"])
        sec_tables = get_paginated_sections(obj, query_obj, table_id_list, True)
        if "error_list" in sec_tables:
            return sec_tables
        for sec in sec_tables:
            obj[sec] = sec_tables[sec]


    clean_obj(obj, config_obj["removelist"]["c_biomarker"], "c_biomarker")
    #obj["crossref"] = []

    if "condition" in obj:
        if "synonyms" in obj["condition"]:
            obj["condition"].pop("synonyms")


    return obj




def biomarker_search(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("biomarker_search", query_obj,config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "biomarker"
    api_name = "biomarker_search"
    list_id = get_hash_id(api_name, record_type, query_obj)
    

    #Get cached object
    cache_coll = "c_initcache"
    mongo_query = {"list_id":list_id}
    cached_obj = dbh[cache_coll].find_one(mongo_query)
    if cached_obj == None:
        cache_coll = "c_usercache"
        cached_obj = dbh[cache_coll].find_one(mongo_query)
    
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}


    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts_list = []
    field2sec = {
        "condition_name":"disease",
        "biomarker_entity_name":"biomarker_component"
    }
    p_list = []
    for p in  query_obj:
        if p not in ["operation","query_type"]:
            ff_list, val_obj = [p], query_obj[p]
            for child_key in []:
                if child_key in val_obj:
                    ff_list.append(child_key)
                    val_obj = val_obj[child_key]
            p_list.append(".".join(ff_list))
    for f in field2sec:
        sec = field2sec[f]
        if p_list == [f]:
            f_parts = f.split(".")
            val = query_obj[f_parts[0]]
            if type(val) is dict:
                for ff in f_parts[1:]:
                    val = val[ff]
            ts_list.append("1a-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
            query_obj_new = {"term":val,"term_category":sec}
            exact_match_flag = True
            res_obj = use_indexed_search("biomarker_search_simple", query_obj_new,config_obj, exact_match_flag)
            ts_list.append("1b-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
            #return {"tslist":ts_list}
            return res_obj

    ts_list.append("0-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    mongo_query = get_mongo_query(query_obj)
    #return mongo_query



    collection = "c_biomarker"
    record_list = []
    prj_obj = {"biomarker_id":1}
    for obj in dbh[collection].find(mongo_query,prj_obj):
        record_list.append(obj["biomarker_id"])
    
    ts_list.append("1-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))


    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":"biomarker_search"
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}
    #return {"tslist":ts_list, "mong":mongo_query}


    return res_obj




def get_mongo_query(query_obj):


    f_map = {
        "biomarker_id":"biomarker_id",
        "biomarker":"biomarker_component.biomarker",
        "biomarker_entity_name":"biomarker_component.assessed_biomarker_entity.recommended_name",
        "biomarker_entity_id":"biomarker_component.assessed_biomarker_entity_id",
        "biomarker_entity_type":"biomarker_component.assessed_entity_type",
        "specimen_name":"biomarker_component.specimen.name",
        "specimen_id":"biomarker_component.specimen.id",
        "specimen_loinc_code":"biomarker_component.specimen.loinc_code",
        "best_biomarker_role":"best_biomarker_role.role",
        "condition_id":"condition.recommended_name.id",
        "condition_name":"condition.recommended_name.name",
        "publication_id":"citation.reference.id"
    }



                        
    cond_objs = []
    for f in f_map:
        if f in query_obj:
            val = query_obj[f]
            path = f_map[f]
            if f == "condition_id":
                cond_objs.append({"$or":[
                    {"condition.recommended_name.id":{'$eq': val}},
                    {"condition.synonyms.id":{'$eq': val}}
                ]})
            elif f == "condition_name":
                cond_objs.append({"$or":[
                    {"condition.recommended_name.name":{'$regex': val, '$options': 'i'}},
                    {"condition.synonyms.name":{'$regex': val, '$options': 'i'}}
                ]}) 
            elif f in ["biomarker_id","biomarker_entity_id","biomarker_entity_type","specimen_id","best_biomarker_role","publication_id"]:
                cond_objs.append({path:{'$eq': val}})
            else:
                cond_objs.append({path:{'$regex': val, '$options': 'i'}})


    operation = query_obj["operation"].lower() if "operation" in query_obj else "and"
    mongo_query = {}
    mongo_query = cond_objs[0] if len(cond_objs) == 1 else mongo_query
    mongo_query = { "$"+operation+"": cond_objs } if len(cond_objs) > 1 else mongo_query

    return mongo_query











def get_simple_mongo_query(query_obj):


    f_map = {
        "biomarker_id":"biomarker_id",
        "biomarker":"biomarker_component.biomarker",
        "biomarker_entity_name":"biomarker_component.assessed_biomarker_entity.recommended_name",
        "biomarker_entity_id":"biomarker_component.assessed_biomarker_entity_id",
        "biomarker_entity_type":"biomarker_component.assessed_entity_type",
        "specimen_name":"biomarker_component.specimen.name",
        "specimen_id":"biomarker_component.specimen.id",
        "specimen_loinc_code":"biomarker_component.specimen.loinc_code",
        "best_biomarker_role":"best_biomarker_role.role",
        "publication_id":"citation.reference.id"
    }


    #query_term = "\"%s\"" % (query_obj["term"])
    query_term = query_obj["term"]
    cond_objs = []
    if query_obj["term_category"] == "any":
        return {'$text': { '$search': query_term}}
    elif query_obj["term_category"] == "biomarker":
        for f in f_map:
            if f in ["condition_id", "condition_name"]:
                continue    
            path = f_map[f]
            cond_objs.append({path:{'$regex': query_term, '$options': 'i'}})   
    elif query_obj["term_category"] == "condition":
        cond_objs = [
            {"condition.recommended_name.id":{'$regex': query_term, '$options': 'i'}},
            {"condition.synonyms.id":{'$regex': query_term, '$options': 'i'}},
            {"condition.recommended_name.name":{'$regex': query_term, '$options': 'i'}},
            {"condition.synonyms.name":{'$regex': query_term, '$options': 'i'}}
        ]

    mongo_query = {} if cond_objs == [] else { "$or": cond_objs }

    return mongo_query



